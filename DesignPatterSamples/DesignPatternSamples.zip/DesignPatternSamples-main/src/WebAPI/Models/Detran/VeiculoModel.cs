﻿namespace DesignPatternSamples.WebAPI.Models.Detran
{
    public class VeiculoModel
    {
        public string Placa { get; set; }
        public string UF { get; set; }
    }
}